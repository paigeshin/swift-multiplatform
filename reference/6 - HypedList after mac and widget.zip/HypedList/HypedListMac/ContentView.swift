//
//  ContentView.swift
//  HypedListMac
//
//  Created by ZappyCode on 10/21/20.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        HypedListSidebarView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
